﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ListBoxSelectionColorChange
{
    public class Address
    {
        public string AddressLine1 { get; set; }
        public string Postcode { get; set; }
        public string Country { get; set; }
    }
}
